"use strict";
(() => {
  // ../../packages/shared/src/copy.ts
  var copy = {
    brand: {
      name: "Parrot",
      tagline: "Watch anything in your language.",
      creatorTagline: "Your videos, everywhere, for free."
    },
    viewer: {
      previewBadge: "Free preview",
      previewEndedTitle: "Want the rest?",
      previewEndedBody: "Unlock the full dub and watch it straight through.",
      unlockCta: "Unlock for {price}",
      unlockingCta: "Unlocking...",
      unlockedTitle: "Squawk! You are in.",
      unlockedBody: "Enjoy - this one is yours to rewatch any time.",
      dubbedInto: "Dubbed into {language}",
      originalLanguage: "Originally in {language}",
      starterCreditTitle: "Test mode: {amount} free credit",
      starterCreditBody: "No real money. This is a demo account we topped up for you.",
      balanceLabel: "Your balance",
      balanceAfter: "{amount} left",
      rewatchCta: "Watch again",
      shareCta: "Share",
      shareCopied: "Link copied",
      cardSoon: "Card and Apple Pay coming soon",
      howItWorksTitle: "How is this free for the creator?",
      howItWorksBody: "Parrot pays to dub the video up front and earns it back a few cents at a time. The creator keeps the bigger share.",
      poweredBy: "Dubbed by Parrot"
    },
    creator: {
      dashboardTitle: "Your earnings",
      totalEarned: "Earned so far",
      pendingLabel: "Ready to claim",
      paidOutLabel: "Already paid out",
      perDubViews: "{count} views",
      perDubUnlocks: "{count} unlocks",
      perDubEarned: "{amount} earned",
      claimCta: "Claim {amount}",
      claimingCta: "Sending...",
      claimedTitle: "On its way",
      claimedBody: "We sent {amount} to your account. It usually lands in a few seconds.",
      claimEmptyTitle: "Nothing to claim yet",
      claimEmptyBody: "As soon as someone unlocks one of your dubs, your earnings show up here.",
      signInPrompt: "Sign in to claim",
      signInBody: "Use the account you posted from, or an email. It takes one tap.",
      earningsWaiting: "We are holding {amount} for you.",
      explainerTitle: "How you get paid",
      explainerBody: "Parrot covers the cost of dubbing your video. Every time someone unlocks the dub, you keep {creatorShare} of what they pay.",
      noDubsTitle: "No dubs yet",
      noDubsBody: 'Reply to one of your posts with "{mention} dub this to Spanish" to get started.'
    },
    bot: {
      mention: "@parrot",
      acceptedReply: "Squawk! On it - dubbing this into {language} now. Your link lands here in about a minute.",
      publishedReply: "Your {language} dub is live -> {link} - you earn every time someone watches it.",
      duplicateReply: "Already dubbed this one into {language} -> {link} - share away.",
      declinedReply: "Passing on this one for now: {reason} Reply again once that changes and I will take another look.",
      declineReasonLowSignal: "not enough interest yet to cover the cost of dubbing it.",
      declineReasonTooLong: "the clip is longer than I can afford to dub right now.",
      declineReasonBudget: "I am low on funds today and keeping a reserve.",
      declineReasonNoVideo: "I could not find a video in that post.",
      declineReasonNotAuthor: "only the person who posted the video can ask me to dub it.",
      declineReasonUnsupportedLanguage: "I cannot dub into that language yet.",
      qcFailedReply: "The dub did not come out well enough to publish, so I scrapped it. No cost to you - I will try again if you ask.",
      firstUnlockReply: "Someone just watched your {language} dub. You earned {amount}.",
      dailySummaryReply: "Your {language} dub earned {amount} from {count} viewers today.",
      statusReply: "That one is {status}. {detail}",
      errorReply: "Something went wrong on my end. Try me again in a minute.",
      rateLimitedReply: "I am a bit swamped right now - give me a few minutes and ask again."
    },
    status: {
      requested: "just came in",
      parsed: "being read",
      evaluating: "being weighed up",
      declined: "passed on",
      approved: "approved",
      dubbing: "being dubbed",
      qc: "in final checks",
      rejectedByQc: "scrapped in checks",
      published: "live",
      earning: "live and earning",
      settled: "paid out",
      failed: "stalled"
    },
    receipt: {
      drawerTitle: "Receipt",
      unlockPaid: "Unlock paid",
      unlockPaidDetail: "You paid {amount} to watch this in {language}.",
      creatorSharePaid: "Creator share sent",
      creatorSharePaidDetail: "{amount} went to {handle}.",
      parrotSharePaid: "Parrot share",
      parrotSharePaidDetail: "{amount} went back to Parrot to cover the dub.",
      payoutSent: "Payout sent",
      payoutSentDetail: "{amount} sent to your account.",
      dubCost: "Dubbing cost",
      dubCostDetail: "Parrot paid {amount} to dub this video.",
      pending: "Sending...",
      timestamp: "on {date}",
      verifyLink: "Verify on Arc",
      verifyHint: "Opens a public record of this payment."
    },
    /** One line per money movement in the live feed on the P&L page. */
    ticker: {
      /** A share of unlock money moved into someone's balance - not a payout. */
      shareBanked: "{amount} banked for {name}",
      /** Money actually sent out to a creator who claimed it. */
      paidOut: "{amount} paid out to {name}",
      dubCost: "Parrot spent {amount} on a dub",
      someone: "an account"
    },
    errors: {
      genericTitle: "That did not work",
      genericBody: "Give it another try. If it keeps happening, it is on us, not you.",
      retryCta: "Try again",
      backCta: "Go back",
      paymentFailedTitle: "The unlock did not go through",
      paymentFailedBody: "You have not been charged. Tap to try once more.",
      insufficientBalanceTitle: "Not enough credit",
      insufficientBalanceBody: "Your test credit has run out. In the real thing you would top up here.",
      dubUnavailableTitle: "This dub is not ready",
      dubUnavailableBody: "It may still be rendering, or it did not pass our quality checks.",
      dubNotFoundTitle: "We cannot find that dub",
      dubNotFoundBody: "The link may be wrong, or the dub may have been taken down.",
      dubbingFailedTitle: "The dub did not come out right",
      dubbingFailedBody: "We scrapped it rather than publish something bad. Nothing was charged to the creator.",
      videoSourceTitle: "We could not read that post",
      videoSourceBody: "Check that the post is public and has a video in it.",
      offlineTitle: "You are offline",
      offlineBody: "Reconnect and we will pick up where you left off.",
      sourceUnavailableTitle: "We cannot reach that service right now",
      sourceUnavailableBody: "It is a temporary outage. We will keep trying in the background.",
      notSignedInTitle: "Sign in to see this",
      notSignedInBody: "One tap with your email or the account you posted from."
    },
    extension: {
      name: "Parrot",
      tagline: "Dubs for the videos in your timeline.",
      watchPrefix: "Also in",
      watchChipTitle: "Watch in {language}. A short preview is free, then {price} to keep watching.",
      dubCta: "Dub this",
      dubCtaAnother: "Dub to another language",
      menuTitle: "Dub this video to",
      menuNote: "Free for you. Parrot covers the cost and you keep {creatorPercent}% of what it earns.",
      menuEmpty: "This video has been requested in every language Parrot speaks.",
      typing: "Asking Parrot under your post...",
      pending: "Parrot is weighing it up...",
      replyPrefix: "Parrot",
      composerFailed: "Could not open the reply box. Reply to your post with: {request}",
      offline: "Parrot cannot be reached right now.",
      popupConnected: "Connected",
      popupDisconnected: "Not connected",
      popupServer: "Parrot server",
      popupSave: "Save",
      popupSaved: "Saved.",
      popupTestMode: "Test mode. Standing in for the real thing right now:",
      popupAllReal: "Everything is running for real.",
      popupDashboard: "See how Parrot decides",
      popupActiveOn: "Active on",
      notDubbedYet: "No dub yet",
      pageSourceNote: "On X, Parrot reads the likes and views from this page. It cannot check them.",
      requestFailed: "Parrot could not take that request. {detail}",
      notAuthor: "Only the person who posted the video can ask for a dub."
    },
    demo: {
      badge: "Test mode",
      simulatedBadge: "Simulated traffic",
      simulatedNote: "These viewers are generated for the demo. The payments they make are real test-mode payments.",
      seedCta: "Seed demo data",
      startTrafficCta: "Start simulated traffic",
      stopTrafficCta: "Stop simulated traffic",
      compressedTimeNote: "Demo mode: a day of results is compressed into a minute."
    }
  };

  // src/messages.ts
  async function ask(request) {
    try {
      const response = await chrome.runtime.sendMessage(request);
      return response ?? { ok: false, error: "no response" };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  }

  // src/popup.ts
  var t = copy.extension;
  function byId(id) {
    const node = document.getElementById(id);
    if (!node) throw new Error(`popup.html is missing #${id}`);
    return node;
  }
  async function render() {
    byId("name").textContent = t.name;
    byId("tagline").textContent = t.tagline;
    byId("server-label").textContent = t.popupServer;
    byId("save").textContent = t.popupSave;
    byId("active-on").textContent = `${t.popupActiveOn}: x.com, localhost`;
    const server = await ask({ type: "getServer" });
    if (server.ok) byId("server").value = server.data;
    const state = byId("state");
    const config = await ask({ type: "config" });
    if (!config.ok) {
      state.dataset.state = "off";
      byId("state-text").textContent = `${t.popupDisconnected}. ${t.offline}`;
      byId("test-section").hidden = true;
      byId("links").hidden = true;
      return;
    }
    state.dataset.state = "on";
    byId("state-text").textContent = t.popupConnected;
    const test = byId("test");
    test.replaceChildren();
    if (config.data.simulated.length > 0) {
      const heading = document.createElement("p");
      heading.textContent = t.popupTestMode;
      const list = document.createElement("ul");
      for (const item of config.data.simulated) {
        const li = document.createElement("li");
        li.textContent = item;
        list.append(li);
      }
      test.append(heading, list);
    } else {
      const line = document.createElement("p");
      line.textContent = t.popupAllReal;
      test.append(line);
    }
    byId("test-section").hidden = false;
    const dashboard = byId("dashboard");
    dashboard.href = `${config.data.webUrl}/agents`;
    dashboard.textContent = t.popupDashboard;
    byId("links").hidden = false;
  }
  byId("server-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const note = byId("server-note");
    const value = byId("server").value;
    void ask({ type: "setServer", server: value }).then((result) => {
      note.textContent = result.ok ? t.popupSaved : result.error;
      void render();
    });
  });
  void render();
})();
