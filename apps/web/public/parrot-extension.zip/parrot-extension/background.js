"use strict";
(() => {
  // src/messages.ts
  var DEFAULT_SERVER = true ? "https://parrot-backend.fly.dev" : "http://localhost:8787";

  // src/background.ts
  var SERVER_KEY = "server";
  var MAX_IDS = 50;
  async function server() {
    try {
      const stored = (await chrome.storage.local.get(SERVER_KEY))[SERVER_KEY];
      if (typeof stored === "string" && /^https?:\/\//.test(stored)) return stored.replace(/\/$/, "");
    } catch {
    }
    return DEFAULT_SERVER;
  }
  async function getJson(path, body) {
    const res = await fetch(`${await server()}${path}`, {
      // Parrot identifies a viewer by cookie; the extension has no business
      // creating or reading one.
      credentials: "omit",
      cache: "no-store",
      ...body === void 0 ? {} : {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      }
    });
    if (!res.ok) {
      const error = await res.json().catch(() => null);
      throw new Error(error?.detail ?? `server answered ${res.status}`);
    }
    return await res.json();
  }
  async function handle(request) {
    switch (request.type) {
      case "config":
        return getJson("/api/extension/config");
      case "posts": {
        const ids = request.ids.filter((id) => typeof id === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(id)).slice(0, MAX_IDS);
        if (ids.length === 0) return { posts: [] };
        return getJson(
          `/api/extension/posts?ids=${encodeURIComponent(ids.join(","))}`
        );
      }
      case "observe":
        return getJson("/api/extension/observe", { posts: request.posts.slice(0, MAX_IDS) });
      case "request":
        return getJson("/api/extension/request", request.body);
      case "forecast":
        if (!/^[A-Za-z0-9_-]{1,64}$/.test(request.postId)) throw new Error("not a post id");
        return getJson(`/api/extension/forecast?postId=${encodeURIComponent(request.postId)}`);
      case "results":
        if (!/^[A-Za-z0-9_-]{1,64}$/.test(request.postId)) throw new Error("not a post id");
        return getJson(`/api/extension/results?postId=${encodeURIComponent(request.postId)}`);
      case "audience":
        return getJson("/api/extension/audience", request.body);
      case "getServer":
        return server();
      case "setServer": {
        const next = request.server.trim().replace(/\/$/, "");
        if (!/^https?:\/\/[^\s/]+$/.test(next)) throw new Error("not a server address");
        await chrome.storage.local.set({ [SERVER_KEY]: next });
        return next;
      }
    }
  }
  function isRequest(message) {
    return typeof message === "object" && message !== null && "type" in message;
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!isRequest(message)) return false;
    handle(message).then(
      (data) => sendResponse({ ok: true, data }),
      (error) => sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      })
    );
    return true;
  });
})();
