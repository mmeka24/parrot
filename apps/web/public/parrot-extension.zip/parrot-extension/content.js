"use strict";
(() => {
  // ../../packages/shared/src/copy.ts
  function fill(template, values) {
    return template.replace(/\{(\w+)\}/g, (_match, key) => {
      const value = values[key];
      if (value === void 0) {
        throw new Error(`copy placeholder {${key}} has no value in: ${template}`);
      }
      return String(value);
    });
  }
  var copy = {
    brand: {
      name: "Parrot",
      tagline: "Watch anything in your language.",
      creatorTagline: "Your videos, everywhere, for free."
    },
    viewer: {
      previewBadge: "Free preview",
      previewEndedTitle: "Want the rest?",
      previewEndedBody: "Unlock the full dub and watch it straight through.",
      unlockCta: "Unlock for {price}",
      unlockingCta: "Unlocking...",
      unlockedTitle: "Squawk! You are in.",
      unlockedBody: "Enjoy - this one is yours to rewatch any time.",
      dubbedInto: "Dubbed into {language}",
      originalLanguage: "Originally in {language}",
      starterCreditTitle: "Test mode: {amount} free credit",
      starterCreditBody: "No real money. This is a demo account we topped up for you.",
      balanceLabel: "Your balance",
      balanceAfter: "{amount} left",
      rewatchCta: "Watch again",
      shareCta: "Share",
      shareCopied: "Link copied",
      cardSoon: "Card and Apple Pay coming soon",
      howItWorksTitle: "How is this free for the creator?",
      howItWorksBody: "Parrot pays to dub the video up front and earns it back a few cents at a time. The creator keeps the bigger share.",
      poweredBy: "Dubbed by Parrot"
    },
    creator: {
      dashboardTitle: "Your earnings",
      totalEarned: "Earned so far",
      pendingLabel: "Ready to claim",
      paidOutLabel: "Already paid out",
      perDubViews: "{count} views",
      perDubUnlocks: "{count} unlocks",
      perDubEarned: "{amount} earned",
      claimCta: "Claim {amount}",
      claimingCta: "Sending...",
      claimedTitle: "On its way",
      claimedBody: "We sent {amount} to your account. It usually lands in a few seconds.",
      claimEmptyTitle: "Nothing to claim yet",
      claimEmptyBody: "As soon as someone unlocks one of your dubs, your earnings show up here.",
      signInPrompt: "Sign in to claim",
      signInBody: "Use the account you posted from, or an email. It takes one tap.",
      earningsWaiting: "We are holding {amount} for you.",
      explainerTitle: "How you get paid",
      explainerBody: "Parrot covers the cost of dubbing your video. Every time someone unlocks the dub, you keep {creatorShare} of what they pay.",
      noDubsTitle: "No dubs yet",
      noDubsBody: 'Reply to one of your posts with "{mention} dub this to Spanish" to get started.'
    },
    bot: {
      mention: "@parrot",
      acceptedReply: "Squawk! On it - dubbing this into {language} now. Your link lands here in about a minute.",
      publishedReply: "Your {language} dub is live -> {link} - you earn every time someone watches it.",
      duplicateReply: "Already dubbed this one into {language} -> {link} - share away.",
      declinedReply: "Passing on this one for now: {reason} Reply again once that changes and I will take another look.",
      declineReasonLowSignal: "not enough interest yet to cover the cost of dubbing it.",
      declineReasonTooLong: "the clip is longer than I can afford to dub right now.",
      declineReasonBudget: "I am low on funds today and keeping a reserve.",
      declineReasonNoVideo: "I could not find a video in that post.",
      declineReasonNotAuthor: "only the person who posted the video can ask me to dub it.",
      declineReasonUnsupportedLanguage: "I cannot dub into that language yet.",
      qcFailedReply: "The dub did not come out well enough to publish, so I scrapped it. No cost to you - I will try again if you ask.",
      firstUnlockReply: "Someone just watched your {language} dub. You earned {amount}.",
      dailySummaryReply: "Your {language} dub earned {amount} from {count} viewers today.",
      statusReply: "That one is {status}. {detail}",
      errorReply: "Something went wrong on my end. Try me again in a minute.",
      rateLimitedReply: "I am a bit swamped right now - give me a few minutes and ask again."
    },
    status: {
      requested: "just came in",
      parsed: "being read",
      evaluating: "being weighed up",
      declined: "passed on",
      approved: "approved",
      dubbing: "being dubbed",
      qc: "in final checks",
      rejectedByQc: "scrapped in checks",
      published: "live",
      earning: "live and earning",
      settled: "paid out",
      failed: "stalled"
    },
    receipt: {
      drawerTitle: "Receipt",
      unlockPaid: "Unlock paid",
      unlockPaidDetail: "You paid {amount} to watch this in {language}.",
      creatorSharePaid: "Creator share sent",
      creatorSharePaidDetail: "{amount} went to {handle}.",
      parrotSharePaid: "Parrot share",
      parrotSharePaidDetail: "{amount} went back to Parrot to cover the dub.",
      payoutSent: "Payout sent",
      payoutSentDetail: "{amount} sent to your account.",
      dubCost: "Dubbing cost",
      dubCostDetail: "Parrot paid {amount} to dub this video.",
      pending: "Sending...",
      timestamp: "on {date}",
      verifyLink: "Verify on Arc",
      verifyHint: "Opens a public record of this payment."
    },
    /** One line per money movement in the live feed on the P&L page. */
    ticker: {
      /** A share of unlock money moved into someone's balance - not a payout. */
      shareBanked: "{amount} banked for {name}",
      /** Money actually sent out to a creator who claimed it. */
      paidOut: "{amount} paid out to {name}",
      dubCost: "Parrot spent {amount} on a dub",
      someone: "an account"
    },
    errors: {
      genericTitle: "That did not work",
      genericBody: "Give it another try. If it keeps happening, it is on us, not you.",
      retryCta: "Try again",
      backCta: "Go back",
      paymentFailedTitle: "The unlock did not go through",
      paymentFailedBody: "You have not been charged. Tap to try once more.",
      insufficientBalanceTitle: "Not enough credit",
      insufficientBalanceBody: "Your test credit has run out. In the real thing you would top up here.",
      dubUnavailableTitle: "This dub is not ready",
      dubUnavailableBody: "It may still be rendering, or it did not pass our quality checks.",
      dubNotFoundTitle: "We cannot find that dub",
      dubNotFoundBody: "The link may be wrong, or the dub may have been taken down.",
      dubbingFailedTitle: "The dub did not come out right",
      dubbingFailedBody: "We scrapped it rather than publish something bad. Nothing was charged to the creator.",
      videoSourceTitle: "We could not read that post",
      videoSourceBody: "Check that the post is public and has a video in it.",
      offlineTitle: "You are offline",
      offlineBody: "Reconnect and we will pick up where you left off.",
      sourceUnavailableTitle: "We cannot reach that service right now",
      sourceUnavailableBody: "It is a temporary outage. We will keep trying in the background.",
      notSignedInTitle: "Sign in to see this",
      notSignedInBody: "One tap with your email or the account you posted from."
    },
    extension: {
      name: "Parrot",
      tagline: "Dubs for the videos in your timeline.",
      watchPrefix: "Also in",
      watchChipTitle: "Watch in {language}. A short preview is free, then {price} to keep watching.",
      dubCta: "Dub this",
      dubCtaAnother: "Dub to another language",
      menuTitle: "Dub this video to",
      menuNote: "Free for you. Parrot covers the cost and you keep {creatorPercent}% of what it earns.",
      menuEmpty: "This video has been requested in every language Parrot speaks.",
      typing: "Asking Parrot under your post...",
      pending: "Parrot is weighing it up...",
      replyPrefix: "Parrot",
      composerFailed: "Could not open the reply box. Reply to your post with: {request}",
      offline: "Parrot cannot be reached right now.",
      popupConnected: "Connected",
      popupDisconnected: "Not connected",
      popupServer: "Parrot server",
      popupSave: "Save",
      popupSaved: "Saved.",
      popupTestMode: "Test mode. Standing in for the real thing right now:",
      popupAllReal: "Everything is running for real.",
      popupDashboard: "See how Parrot decides",
      popupActiveOn: "Active on",
      notDubbedYet: "No dub yet",
      pageSourceNote: "On X, Parrot reads the likes and views from this page. It cannot check them.",
      requestFailed: "Parrot could not take that request. {detail}",
      notAuthor: "Only the person who posted the video can ask for a dub."
    },
    demo: {
      badge: "Test mode",
      simulatedBadge: "Simulated traffic",
      simulatedNote: "These viewers are generated for the demo. The payments they make are real test-mode payments.",
      seedCta: "Seed demo data",
      startTrafficCta: "Start simulated traffic",
      stopTrafficCta: "Stop simulated traffic",
      compressedTimeNote: "Demo mode: a day of results is compressed into a minute."
    }
  };

  // ../../packages/shared/src/x-dom.ts
  var X_TESTID = {
    /** One post. An <article>. */
    tweet: "tweet",
    /** Display name, @handle and the timestamp permalink. */
    userName: "User-Name",
    /** The post body. */
    tweetText: "tweetText",
    /** Wraps the <video>. */
    videoPlayer: "videoPlayer",
    /** The inner video wrapper on x.com; a second hook for the same thing. */
    videoComponent: "videoComponent",
    reply: "reply",
    retweet: "retweet",
    like: "like",
    unlike: "unlike",
    /** The composer's text box, in the reply dialog and inline. */
    composerInput: "tweetTextarea_0",
    /** Submit, inside the reply dialog. */
    composerSubmit: "tweetButton",
    /** Submit, on the inline composer. */
    composerSubmitInline: "tweetButtonInline",
    /** The signed-in account chip in the side nav; contains "@handle". */
    accountSwitcher: "SideNav_AccountSwitcher_Button",
    /** The side nav's Profile link, href "/{handle}". */
    profileLink: "AppTabBar_Profile_Link",
    primaryColumn: "primaryColumn"
  };
  function xSelector(id) {
    return `[data-testid="${id}"]`;
  }
  var X_STATUS_PATH = /^\/([A-Za-z0-9_]{1,15})\/status\/([A-Za-z0-9_-]+)/;
  function parseStatusHref(href) {
    let path;
    try {
      path = new URL(href, "https://x.invalid").pathname;
    } catch {
      return null;
    }
    const match = X_STATUS_PATH.exec(path);
    if (!match || !match[1] || !match[2]) return null;
    return { handle: match[1].toLowerCase(), postId: match[2] };
  }

  // src/messages.ts
  async function ask(request) {
    try {
      const response = await chrome.runtime.sendMessage(request);
      return response ?? { ok: false, error: "no response" };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  }

  // src/dom.ts
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
      if (value === void 0 || value === false) continue;
      node.setAttribute(key, value === true ? "" : value);
    }
    for (const child of children) {
      if (child === null || child === void 0 || child === false) continue;
      node.append(typeof child === "string" ? document.createTextNode(child) : child);
    }
    return node;
  }
  var SVG_NS = "http://www.w3.org/2000/svg";
  function svg(size, viewBox, shapes) {
    const root = document.createElementNS(SVG_NS, "svg");
    root.setAttribute("width", String(size));
    root.setAttribute("height", String(size));
    root.setAttribute("viewBox", viewBox);
    root.setAttribute("aria-hidden", "true");
    root.setAttribute("focusable", "false");
    for (const [tag, attrs] of shapes) {
      const shape = document.createElementNS(SVG_NS, tag);
      for (const [key, value] of Object.entries(attrs)) shape.setAttribute(key, value);
      root.append(shape);
    }
    return root;
  }
  function parrotMark(size) {
    return svg(size, "0 0 64 64", [
      [
        "path",
        {
          d: "M41 10c-11.5 0-20.5 8.4-20.5 19.6 0 6.2 2.6 11 6.4 14.8C31 48.5 33 52.3 33 56h12c0-5 1.7-8.2 4.6-11.4C53.9 39.8 57 34.6 57 28.4 57 17.8 51.6 10 41 10Z",
          fill: "var(--p-teal)"
        }
      ],
      [
        "path",
        {
          d: "M43 10c1-4.2-.6-7.4-4.6-9.2 1.2 3.4.5 5.8-2.1 7.2-1.4-3.2-4-4.8-7.6-4.8 2.2 2.6 2.9 5 2.1 7.3C33.9 9.2 37.4 8.9 43 10Z",
          fill: "var(--p-mango)"
        }
      ],
      ["circle", { cx: "37", cy: "26", r: "4.6", fill: "#fffdfa" }],
      ["circle", { cx: "38.2", cy: "26.4", r: "2.4", fill: "#1b1a17" }],
      [
        "path",
        {
          d: "M24 24.5c-6.6 1.3-11.4 5-14 11.2 4.6-.7 7.6.2 9.3 2.6 1.4 2 3.9 2.3 5.9.8 2.5-1.9 3.8-5.2 3.8-9.6 0-3.3-1.7-5.4-5-5Z",
          fill: "var(--p-mango)"
        }
      ]
    ]);
  }
  function waitFor(test, timeoutMs) {
    return new Promise((resolve) => {
      const started = Date.now();
      const poll = () => {
        const value = test();
        if (value) return resolve(value);
        if (Date.now() - started > timeoutMs) return resolve(null);
        window.setTimeout(poll, 50);
      };
      poll();
    });
  }

  // src/styles.ts
  var STRIP_CSS = `
:host {
  all: initial;
  display: block;
  --p-ink: #1b1a17;
  --p-soft: #5d574c;
  --p-rule: #e6d9c4;
  --p-wash: #fdf7ef;
  --p-mango: #f26a1b;
  --p-mango-deep: #c84f07;
  --p-mango-wash: #fdeadc;
  --p-teal: #0f7a6c;
  --p-teal-wash: #d9efe9;
  --p-bad: #b32a3f;
  --p-on-accent: #fffdfa;
  --p-focus: #2b5fd9;
}
@media (prefers-color-scheme: dark) {
  :host {
    --p-ink: #f6efe3;
    --p-soft: #bdb3a1;
    --p-rule: #403a2f;
    --p-wash: #1d1b16;
    --p-mango: #ff8a3d;
    --p-mango-deep: #ffa566;
    --p-mango-wash: #30200f;
    --p-teal: #4fd1b9;
    --p-teal-wash: #0f2a26;
    --p-bad: #ff8095;
    --p-on-accent: #17120b;
    --p-focus: #9bb8ff;
  }
}
* { box-sizing: border-box; }
.strip {
  margin-top: 10px;
  font: 13px/18px ui-sans-serif, system-ui, 'Segoe UI', Roboto, sans-serif;
  color: var(--p-ink);
}
.row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 8px;
}
.brand {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-weight: 700;
  color: var(--p-soft);
}
.label { color: var(--p-soft); }
.chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 10px 0 8px;
  border-radius: 999px;
  border: 1px solid transparent;
  background: var(--p-teal-wash);
  color: var(--p-teal);
  font-weight: 700;
  text-decoration: none;
  white-space: nowrap;
}
.chip:hover { border-color: var(--p-teal); }
.chip .tri {
  width: 0; height: 0;
  border-left: 7px solid currentColor;
  border-top: 4.5px solid transparent;
  border-bottom: 4.5px solid transparent;
}
.spacer { flex: 1 1 auto; }
button {
  font: inherit;
  cursor: pointer;
}
.cta {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 12px;
  border-radius: 999px;
  border: 0;
  background: var(--p-mango);
  color: var(--p-on-accent);
  font-weight: 700;
}
.cta:hover { background: var(--p-mango-deep); }
.cta[aria-expanded="true"] { background: var(--p-mango-deep); }
.cta:disabled { opacity: 0.6; cursor: default; }
.caret {
  width: 0; height: 0;
  border-top: 5px solid currentColor;
  border-left: 4px solid transparent;
  border-right: 4px solid transparent;
}
.pending {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--p-mango-deep);
  font-weight: 600;
}
.dot {
  width: 7px; height: 7px; border-radius: 999px;
  background: var(--p-mango);
  animation: pulse 1.1s ease-in-out infinite;
}
@keyframes pulse { 50% { opacity: 0.25; } }
.menu {
  margin-top: 8px;
  padding: 10px 12px 12px;
  border-radius: 14px;
  border: 1px solid var(--p-rule);
  background: var(--p-wash);
}
.menu-title { font-weight: 700; margin: 0 0 8px; }
.langs { display: flex; flex-wrap: wrap; gap: 6px; }
.lang {
  height: 30px;
  padding: 0 12px;
  border-radius: 999px;
  border: 1px solid var(--p-rule);
  background: transparent;
  color: var(--p-ink);
  font-weight: 600;
}
.lang:hover { border-color: var(--p-mango); background: var(--p-mango-wash); }
.note { margin: 10px 0 0; color: var(--p-soft); }
.reply {
  margin: 8px 0 0;
  padding-left: 10px;
  border-left: 3px solid var(--p-rule);
  color: var(--p-soft);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  overflow-wrap: anywhere;
}
.reply b { color: var(--p-ink); }
.status { margin: 8px 0 0; color: var(--p-soft); }
.status.error { color: var(--p-bad); }
a:focus-visible, button:focus-visible {
  outline: 2px solid var(--p-focus);
  outline-offset: 2px;
}
@media (prefers-reduced-motion: reduce) {
  .dot { animation: none; }
}
`;

  // src/content.ts
  var t = copy.extension;
  var ON_X = /(^|\.)(x|twitter)\.com$/.test(location.hostname);
  var HOST_ATTR = "data-parrot-strip";
  var POLL_IDLE_MS = 4e3;
  var POLL_BUSY_MS = 1200;
  var config = null;
  var statuses = /* @__PURE__ */ new Map();
  var local = /* @__PURE__ */ new Map();
  var drawn = /* @__PURE__ */ new WeakMap();
  var timer = null;
  function findPosts() {
    const found = [];
    for (const article of document.querySelectorAll(xSelector(X_TESTID.tweet))) {
      if (article.parentElement?.closest(xSelector(X_TESTID.tweet))) continue;
      const postId = permalinkOf(article);
      if (postId) found.push({ article, postId });
    }
    return found;
  }
  function permalinkOf(article) {
    const anchors = [
      article.querySelector("a time")?.closest("a"),
      ...article.querySelectorAll('a[href*="/status/"]')
    ];
    for (const anchor of anchors) {
      const href = anchor?.getAttribute("href");
      const parsed = href ? parseStatusHref(href) : null;
      if (parsed) return parsed.postId;
    }
    return null;
  }
  function countIn(label) {
    const match = label?.match(/\d[\d,.\s]*/);
    if (!match) return null;
    const value = Number(match[0].replace(/[^\d]/g, ""));
    return Number.isFinite(value) ? value : null;
  }
  function clockToSeconds(text) {
    const match = text.match(/(\d+):(\d{2})(?::(\d{2}))?/);
    if (!match) return null;
    const parts = match.slice(1).filter((p) => p !== void 0).map(Number);
    return parts.reduce((total, part) => total * 60 + part, 0) || null;
  }
  function readPost(article, postId) {
    const player = videoIn(article);
    if (!player) return null;
    const anchor = article.querySelector("a time")?.closest("a");
    const parsed = anchor ? parseStatusHref(anchor.getAttribute("href") ?? "") : null;
    if (!parsed || parsed.postId !== postId) return null;
    const label = (id) => article.querySelector(xSelector(id))?.getAttribute("aria-label") ?? null;
    const video = player.querySelector("video");
    let durationS = video && Number.isFinite(video.duration) && video.duration > 0 ? video.duration : null;
    if (durationS === null) {
      const clocks = (player.textContent ?? "").match(/\d+:\d{2}(?::\d{2})?/g);
      const last = clocks?.[clocks.length - 1];
      durationS = last ? clockToSeconds(last) : null;
    }
    const userName = article.querySelector(xSelector(X_TESTID.userName));
    const displayName = userName?.querySelector("span")?.textContent?.trim() ?? parsed.handle;
    const views = countIn(
      article.querySelector('a[href$="/analytics"]')?.getAttribute("aria-label")
    );
    const time = article.querySelector("time")?.getAttribute("datetime") ?? null;
    return {
      postId,
      authorHandle: parsed.handle,
      authorDisplayName: displayName.slice(0, 100),
      text: (article.querySelector(xSelector(X_TESTID.tweetText))?.textContent ?? "").slice(0, 2e3),
      metrics: {
        replies: countIn(label(X_TESTID.reply)) ?? 0,
        reposts: countIn(label(X_TESTID.retweet)) ?? 0,
        likes: countIn(label(X_TESTID.like) ?? label(X_TESTID.unlike)) ?? 0,
        views
      },
      durationS: durationS === null ? null : Math.round(durationS * 10) / 10,
      createdAt: time && !Number.isNaN(Date.parse(time)) ? new Date(time).toISOString() : null
    };
  }
  function videoIn(article) {
    return article.querySelector(xSelector(X_TESTID.videoPlayer)) ?? article.querySelector(xSelector(X_TESTID.videoComponent)) ?? article.querySelector("video")?.parentElement ?? null;
  }
  function currentHandle() {
    const chip = document.querySelector(xSelector(X_TESTID.accountSwitcher));
    const fromChip = chip?.textContent?.match(/@([A-Za-z0-9_]{1,15})/)?.[1];
    if (fromChip) return fromChip.toLowerCase();
    const profile = document.querySelector(xSelector(X_TESTID.profileLink))?.getAttribute("href")?.match(/^\/([A-Za-z0-9_]{1,15})$/)?.[1];
    return profile?.toLowerCase() ?? null;
  }
  function stateFor(postId) {
    let state = local.get(postId);
    if (!state) {
      state = { menuOpen: false, busy: false, sentAt: null, message: null };
      local.set(postId, state);
    }
    return state;
  }
  var refreshing = false;
  var again = false;
  async function refresh() {
    if (timer !== null) window.clearTimeout(timer);
    timer = null;
    if (refreshing) {
      again = true;
      return;
    }
    refreshing = true;
    try {
      await refreshOnce();
    } finally {
      refreshing = false;
    }
    if (again) {
      again = false;
      scheduleSoon();
      return;
    }
    const busy = [...local.values()].some((s) => s.busy || s.sentAt !== null) || [...statuses.values()].some((s) => s.pending);
    timer = window.setTimeout(() => void refresh(), busy ? POLL_BUSY_MS : POLL_IDLE_MS);
  }
  async function refreshOnce() {
    const posts = findPosts();
    if (posts.length > 0) {
      if (!config) {
        const response = await ask({ type: "config" });
        if (response.ok) config = response.data;
      }
      if (config && ON_X) {
        const seen = posts.map((p) => readPost(p.article, p.postId)).filter((p) => p !== null);
        if (seen.length > 0) await ask({ type: "observe", posts: seen });
      }
      if (config) {
        const ids = [...new Set(posts.map((p) => p.postId))];
        const response = await ask({ type: "posts", ids });
        if (response.ok) {
          for (const status of response.data.posts) statuses.set(status.postId, status);
        }
      }
      drawAll();
      report(posts.length);
    }
  }
  var lastReport = "";
  function report(found) {
    const withVideo = findPosts().filter((p) => videoIn(p.article) !== null).length;
    const line = `[Parrot] ${found} posts on the page, ${withVideo} with video; signed in as ${currentHandle() ?? "(not detected)"}; server ${config ? "reachable" : "NOT reachable"}`;
    if (line !== lastReport) {
      lastReport = line;
      console.info(line);
    }
  }
  function drawAll() {
    const me = currentHandle();
    for (const { article, postId } of findPosts()) {
      const status = statuses.get(postId);
      const state = stateFor(postId);
      if (state.sentAt !== null && status?.lastReply) {
        if (new Date(status.lastReply.at).getTime() >= state.sentAt - 2e3) {
          state.sentAt = null;
        }
      }
      if (state.sentAt !== null && Date.now() - state.sentAt > 3e4) state.sentAt = null;
      draw(article, postId, status, state, me);
    }
  }
  var soonAt = 0;
  function scheduleSoon() {
    const now = Date.now();
    if (timer !== null && soonAt > now && soonAt - now <= 150) return;
    if (timer !== null) window.clearTimeout(timer);
    soonAt = now + 150;
    timer = window.setTimeout(() => void refresh(), 150);
  }
  function hostFor(article) {
    let host = article.querySelector(`[${HOST_ATTR}]`);
    if (!host || !host.shadowRoot) {
      host = el("div", { [HOST_ATTR]: "" });
      for (const type of ["click", "mousedown", "pointerdown", "keydown"]) {
        host.addEventListener(type, (event) => event.stopPropagation());
      }
      const root = host.attachShadow({ mode: "open" });
      root.append(el("style", {}, [STRIP_CSS]));
      const actions = article.querySelector('[role="group"]');
      if (actions?.parentElement) actions.after(host);
      else article.append(host);
    }
    return host.shadowRoot;
  }
  function removeStrip(article) {
    article.querySelector(`[${HOST_ATTR}]`)?.remove();
  }
  function draw(article, postId, status, state, me) {
    if (!config || !status || !status.known) return removeStrip(article);
    const isAuthor = me !== null && status.authorHandle === me;
    const watchable = status.dubs.filter((d) => d.watchable);
    const pending = status.pending || state.sentAt !== null || state.busy;
    const canDub = isAuthor && status.hasVideo;
    if (!status.hasVideo && watchable.length === 0 && !pending && !state.message) {
      return removeStrip(article);
    }
    const signature = JSON.stringify([
      watchable.map((d) => d.jobId),
      pending,
      canDub,
      state.menuOpen,
      state.busy,
      state.message,
      isAuthor ? status.lastReply : null,
      status.dubs.map((d) => d.languageCode)
    ]);
    const root = hostFor(article);
    if (drawn.get(root) === signature) return;
    drawn.set(root, signature);
    const strip = el("div", { class: "strip" });
    const row = el("div", { class: "row" }, [
      el("span", { class: "brand" }, [parrotMark(16), t.name])
    ]);
    if (watchable.length > 0) {
      row.append(el("span", { class: "label" }, [t.watchPrefix]));
      for (const dub of watchable) row.append(watchChip(dub));
    } else if (!pending && !canDub) {
      row.append(el("span", { class: "label" }, [t.notDubbedYet]));
    }
    if (pending) {
      row.append(
        el("span", { class: "pending", role: "status" }, [
          el("span", { class: "dot" }),
          state.busy ? t.typing : t.pending
        ])
      );
    }
    if (canDub) {
      row.append(el("span", { class: "spacer" }));
      const button = el(
        "button",
        {
          type: "button",
          class: "cta",
          "aria-haspopup": "true",
          "aria-expanded": state.menuOpen ? "true" : "false",
          disabled: state.busy
        },
        [status.dubs.length > 0 ? t.dubCtaAnother : t.dubCta, el("span", { class: "caret" })]
      );
      button.addEventListener("click", () => {
        state.menuOpen = !state.menuOpen;
        state.message = null;
        drawAll();
      });
      row.append(button);
    }
    strip.append(row);
    if (canDub && state.menuOpen && !state.busy) strip.append(languageMenu(article, postId, status, state));
    if (state.message) {
      strip.append(
        el("p", { class: `status${state.message.error ? " error" : ""}`, role: "status" }, [
          state.message.text
        ])
      );
    } else if (isAuthor && status.lastReply && !pending) {
      strip.append(el("p", { class: "reply" }, [el("b", {}, [`${t.replyPrefix}: `]), status.lastReply.text]));
    }
    root.querySelector(".strip")?.remove();
    root.append(strip);
  }
  function watchChip(dub) {
    return el(
      "a",
      {
        class: "chip",
        href: dub.watchUrl ?? "#",
        target: "_blank",
        rel: "noopener",
        title: fill(t.watchChipTitle, {
          language: dub.languageName,
          price: config?.unlockPrice.display ?? ""
        })
      },
      [el("span", { class: "tri" }), dub.languageName]
    );
  }
  function languageMenu(article, postId, status, state) {
    const taken = new Set(status.dubs.map((d) => d.languageCode));
    const open = (config?.languages ?? []).filter((l) => !taken.has(l.code));
    const menu = el("div", { class: "menu", role: "menu", "aria-label": t.menuTitle });
    menu.append(el("p", { class: "menu-title" }, [t.menuTitle]));
    if (open.length === 0) {
      menu.append(el("p", { class: "note" }, [t.menuEmpty]));
      return menu;
    }
    const langs = el("div", { class: "langs" });
    for (const language of open) {
      const item = el("button", { type: "button", class: "lang", role: "menuitem" }, [
        language.englishName
      ]);
      item.addEventListener("click", () => void requestDub(article, postId, language, state));
      langs.append(item);
    }
    menu.append(langs);
    menu.append(
      el("p", { class: "note" }, [
        fill(t.menuNote, { creatorPercent: config?.creatorPercent ?? 60 })
      ])
    );
    if (status.source === "page") menu.append(el("p", { class: "note" }, [t.pageSourceNote]));
    menu.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        state.menuOpen = false;
        drawAll();
      }
    });
    return menu;
  }
  async function requestDub(article, postId, language, state) {
    if (!config) return;
    state.menuOpen = false;
    state.busy = true;
    state.message = null;
    drawAll();
    if (ON_X) {
      const response = await ask({
        type: "request",
        body: { postId, languageCode: language.code, requesterHandle: currentHandle() ?? "" }
      });
      state.busy = false;
      if (response.ok) state.sentAt = Date.now();
      else state.message = { text: fill(t.requestFailed, { detail: response.error }), error: true };
      drawAll();
      scheduleSoon();
      return;
    }
    const request = fill(config.requestTemplate, {
      handle: config.botHandle,
      language: language.englishName
    });
    const sent = await replyUnder(article, request);
    state.busy = false;
    if (sent) {
      state.sentAt = Date.now();
    } else {
      state.message = { text: fill(t.composerFailed, { request }), error: true };
    }
    drawAll();
    scheduleSoon();
  }
  async function replyUnder(article, text) {
    const replyButton = article.querySelector(xSelector(X_TESTID.reply));
    if (!replyButton) return false;
    replyButton.click();
    const dialogInput = await waitFor(
      () => document.querySelector(`[role="dialog"] ${xSelector(X_TESTID.composerInput)}`),
      2e3
    );
    const input = dialogInput ?? document.querySelector(xSelector(X_TESTID.composerInput));
    if (!input) return false;
    typeInto(input, text);
    const scope = submitScope(input);
    const submit = await waitFor(() => {
      const button = scope.querySelector(SUBMIT_SELECTOR);
      if (!button) return null;
      const disabled = button.disabled || button.getAttribute("aria-disabled") === "true";
      return disabled ? null : button;
    }, 3e3);
    if (!submit) return false;
    submit.click();
    const done = await waitFor(
      () => !input.isConnected || readText(input).trim() === "",
      8e3
    );
    return done !== null;
  }
  var SUBMIT_SELECTOR = `${xSelector(X_TESTID.composerSubmit)}, ${xSelector(X_TESTID.composerSubmitInline)}`;
  function submitScope(input) {
    const dialog = input.closest('[role="dialog"]');
    if (dialog) return dialog;
    let node = input.parentElement;
    while (node && !node.querySelector(SUBMIT_SELECTOR)) node = node.parentElement;
    return node ?? document;
  }
  function typeInto(input, text) {
    input.focus();
    if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
      const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(input, text);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    const editable = input.isContentEditable ? input : input.querySelector('[contenteditable="true"]');
    if (!editable) return;
    editable.focus();
    document.execCommand("insertText", false, text);
  }
  function readText(input) {
    if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) return input.value;
    return input.textContent ?? "";
  }
  function start() {
    let frame = 0;
    const observer = new MutationObserver((mutations) => {
      const ours = mutations.every(
        (m) => m.target instanceof Element && m.target.closest(`[${HOST_ATTR}]`) !== null
      );
      if (ours || frame !== 0) return;
      frame = window.requestAnimationFrame(() => {
        frame = 0;
        const unseen = findPosts().some((p) => !statuses.has(p.postId));
        drawAll();
        if (unseen) scheduleSoon();
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") scheduleSoon();
    });
    void refresh();
  }
  start();
})();
